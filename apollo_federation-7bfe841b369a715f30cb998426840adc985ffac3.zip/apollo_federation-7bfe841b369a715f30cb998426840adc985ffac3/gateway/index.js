const { ApolloServer } = require('apollo-server');
const { ApolloGateway, RemoteGraphQLDataSource } = require('@apollo/gateway');

const gateway = new ApolloGateway({
    serviceList: [
        {
            name: 'Location',
            url: 'http://localhost:4001',
        },
        {
            name: 'Reviews',
            url: 'http://localhost:4002/',
        },
    ],
});

async function start() {
    const server = new ApolloServer({
        gateway,
        subscriptions: false,
    });

    server.listen(4004).then(() => console.log('running'));
}

start();
